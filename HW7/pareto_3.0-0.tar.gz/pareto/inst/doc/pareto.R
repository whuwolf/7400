### R code from vignette source 'pareto.Rnw'

###################################################
### code chunk number 1: pareto.Rnw:11-14
###################################################
library(pareto)
library(xtable)
#N <- 5


###################################################
### code chunk number 2: pareto.Rnw:22-24
###################################################
dpareto(4, 2, 1)
dpareto(4, 2, 1, log = TRUE)


###################################################
### code chunk number 3: pareto.Rnw:29-32
###################################################
ppareto(5, 2, 1)
ppareto(5, 2, 1, lower.tail = FALSE)
ppareto(5, 2, 1, lower.tail = FALSE, log.p = TRUE)


###################################################
### code chunk number 4: pareto.Rnw:37-40
###################################################
qpareto(0.6, 2, 1)
qpareto(0.6, 2, 1, lower.tail = FALSE)
qpareto(log(0.6), 2, 1, lower.tail = FALSE, log.p = TRUE)


###################################################
### code chunk number 5: pareto.Rnw:49-51
###################################################
dpareto(1:5, 2, 1)
dpareto(1:5, 2, 1, log = TRUE)


###################################################
### code chunk number 6: pareto.Rnw:56-59
###################################################
ppareto(1:5, 2, 1)
ppareto(1:5, 2, 1, lower.tail = FALSE)
ppareto(1:5, 2, 1, lower.tail = FALSE, log.p = TRUE)


###################################################
### code chunk number 7: pareto.Rnw:64-67
###################################################
qpareto(seq(0,1,0.2), 2, 1)
qpareto(seq(0,1,0.2), 2, 1, lower.tail = FALSE)
qpareto(log(seq(0,1,0.2)), 2, 1, lower.tail = FALSE, log.p = TRUE)


###################################################
### code chunk number 8: pareto.Rnw:72-78
###################################################
x <- c(1:5)
m<-cbind(x, dpareto(x, 2, 1), ppareto(x, 2, 1))
colnames(m)<-c("x", "dpareto", "ppareto")
xtable(as.data.frame(m),align=rep("c",4),
       caption="Results for dpareto(1:5, 2, 1) and ppareto(1:5, 2, 1)",
       label="tab:pareto")


###################################################
### code chunk number 9: pareto.Rnw:83-84
###################################################
plot(seq(0,0.99,0.001), qpareto(seq(0,0.99,0.001),2,1),xlab = "probability", ylab="quantile", type="l", col="red")


